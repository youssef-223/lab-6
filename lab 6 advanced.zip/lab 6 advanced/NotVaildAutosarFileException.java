
/**
 *
 * @author noha3
 */
public class NotVaildAutosarFileException extends Exception {
    public NotVaildAutosarFileException(String message){
        System.out.println(message);
    }
    
}
